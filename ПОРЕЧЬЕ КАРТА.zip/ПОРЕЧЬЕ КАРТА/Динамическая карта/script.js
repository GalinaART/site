"use script"
<select onchange="window.location.href = this.options[this.selectedIndex].value">
	<option value=""></option>
	<option value="https://example.com/?brand=1">Peronda</option>
	<option value="https://example.com/?brand=2">Porcelanite Dos</option>
	<option value="https://example.com/?brand=3">Piemme Valentino</option>
	<option value="https://example.com/?brand=4">Dune</option>
	<option value="https://example.com/?brand=5">Atlas Concorde</option>
	<option value="https://example.com/?brand=6">Colorker</option>
	<option value="https://example.com/?brand=7">Golden Tile</option>
	<option value="https://example.com/?brand=8">Grespania</option>
	<option value="https://example.com/?brand=9">Vallelunga</option>
	<option value="https://example.com/?brand=10">Fanal</option>
</select>